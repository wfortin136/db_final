DROP TABLE IF EXISTS Location;
create table Location(
  locID int PRIMARY KEY auto_increment,
  city varchar(15),
  state varchar(15),
  country varchar(15));

DROP TABLE IF EXISTS Promotion;
CREATE TABLE Promotion(
  promID int PRIMARY KEY auto_increment,
  name varchar(50));

DROP TABLE IF EXISTS Weightclass;
CREATE TABLE Weightclass(
  classID int PRIMARY KEY auto_increment,
  className varchar(50),
  weight int);

DROP TABLE IF EXISTS Fightcard;
CREATE TABLE Fightcard(
  fightcardID int PRIMARY KEY auto_increment,
  promID int,
  fightcardName varchar(20),
  locID int,
  fightDate date);

DROP TABLE IF EXISTS Fighter;
CREATE TABLE Fighter(
  fighterID int PRIMARY KEY auto_increment,
  fighterName varchar(20),
  wins int,
  losses int,
  draws int,
  nc int);

DROP TABLE IF EXISTS Champhist;
CREATE TABLE Champhist(
  histID int PRIMARY KEY auto_increment,
  promID int,
  classID int, 
  fighterID int,
  start date,
  end date);

DROP TABLE IF EXISTS Fight;
CREATE TABLE Fight(
  fightID int PRIMARY KEY auto_increment,
  fightcardID int,
  fightNum int,
  weightClass int,
  cardLevel int,
  championship boolean,
  fightTime int,
  method varchar(100));

DROP TABLE IF EXISTS Fightstats;
CREATE TABLE Fightstats(
  fightstatID int PRIMARY KEY auto_increment,
  fightID int,
  fighterID int,
  round int,
  kd int,
  str_landed int,
  str_thrown int,
  td_att int,
  td_com int,
  sub_att int);

-- ALTER TABLE Fightstats DROP INDEX FS_fightID;
create index FS_fightID
on Fightstats (fightID);

DROP TABLE IF EXISTS Fighterstats;
#CREATE TABLE Fighterstats(
#  fighterstatID int PRIMARY KEY auto_increment,
#  fighterID int,
#  round int,
#  kd int,
#  str_landed int,
#  str_thrown int,
#  td_att int,
#  td_com int,
#  sub_att int);

DROP TABLE IF EXISTS Judge;
CREATE TABLE Judge(
  judgeID int PRIMARY KEY auto_increment,
  judgeName varchar(20));

DROP TABLE IF EXISTS Scorecard;
#CREATE TABLE Scorecard(
#  scorecardID int PRIMARY KEY auto_increment,
#  judgeID int,
#  fightID int,
#  fighterID int,
#  tot_score int);

DROP TABLE IF EXISTS Judgescore;
CREATE TABLE Judgescore(
  judgescoreID int PRIMARY KEY auto_increment,
  judgeID int,
  fightID int,
  fighterID int,
  round int,
  score int);

-- ALTER TABLE Judgescore DROP INDEX J_fightID;
create index J_fightID
on Judgescore (fightID);
