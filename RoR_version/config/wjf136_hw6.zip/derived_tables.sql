#Derive Fighterstats table from Fightstats

create or replace view Fighterstats as
select fighterID, round, sum(kd), sum(str_landed), sum(str_thrown), sum(td_att),
          sum(td_com), sum(sub_att)
from Fightstats
group by fighterID, round;

#Derive Scorcards from Judgescore
create or replace view Scorecard as
select judgeID, fightID, fighterID, sum(score)
from Judgescore
group by judgeID, fightID, fighterID;
