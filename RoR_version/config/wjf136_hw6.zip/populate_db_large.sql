TRUNCATE TABLE Promotion;
#1-4
INSERT INTO Promotion VALUES (null,'UFC');
set @ufc = last_insert_id();
INSERT INTO Promotion VALUES (null,'Strikeforce');
set @stf = last_insert_id();
INSERT INTO Promotion VALUES (null,'Bellator');
set @bell = last_insert_id();
INSERT INTO Promotion VALUES (null, 'Pride');
set @prid = last_insert_id();

TRUNCATE TABLE Weightclass;
#1-8
INSERT INTO Weightclass VALUES (null ,'Flyweight', 125);
set @fly = last_insert_id();
INSERT INTO Weightclass VALUES (null ,'Bantomweight', 135);
set @ban = last_insert_id();
INSERT INTO Weightclass VALUES (null ,'Featherweight', 145);
set @fet = last_insert_id();
INSERT INTO Weightclass VALUES (null ,'Lightweight', 155);
set @lit = last_insert_id();
INSERT INTO Weightclass VALUES (null ,'Welterweight', 170);
set @wel = last_insert_id();
INSERT INTO Weightclass VALUES (null ,'Middleweight', 185);
set @mid = last_insert_id();
INSERT INTO Weightclass VALUES (null ,'Light Heavyweight', 205);
set @lhw = last_insert_id();
INSERT INTO Weightclass VALUES (null ,'Heavyweight', 265);
set @hw = last_insert_id();

truncate table Location;
load data local infile 'data/locations.txt' into table Location
fields terminated by '::';

truncate table Fighter;
load data local infile 'data/fighters.txt' into table Fighter
fields terminated by '::';

truncate table Judge;
load data local infile 'data/judges.txt' into table Judge
fields terminated by '::';

truncate table Fightcard;
load data local infile 'data/fightcards.txt' into table Fightcard
fields terminated by '::';

truncate table Fight;
load data local infile 'data/fights.txt' into table Fight
fields terminated by '::';

truncate table Fightstats;
load data local infile 'data/fightstats.txt' into table Fightstats
fields terminated by '::';

truncate table Judgescore;
load data local infile 'data/judgescores.txt' into table Judgescore
fields terminated by '::';

